# Ali Hoca Bağlama Kitapları

WebView tabanlı Android uygulaması. `MainActivity` içinde `ACTION_OPEN_DOCUMENT_TREE` ve `AndroidPicker` JavaScript köprüsü bulunur.

- Klasör seçimi kullanıcı düğmesine bastığında açılır.
- Seçim kalıcı URI okuma izniyle alınır.
- JavaScript callback'i `window.onAndroidLibraryChanged` ile çağrılır.
- Hedef: Android 16 / targetSdk 35.

## APK üretimi
GitHub'a yükleyin → Actions → "Build APK" → çıkan `app-debug` artifact'ını indirin.
Yerelde: JDK 17 + Android SDK 35 + Gradle 8.9 ile `gradle assembleDebug`.
