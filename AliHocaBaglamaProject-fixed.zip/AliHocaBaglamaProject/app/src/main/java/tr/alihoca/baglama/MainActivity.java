package tr.alihoca.baglama;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.view.View;
import android.widget.FrameLayout;
import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.util.Base64;
import java.io.*;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
  private static final int REQUEST_TREE = 0x1bc0;
  private WebView webView;
  private AndroidPicker picker;

  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    FrameLayout root = new FrameLayout(this); root.setFitsSystemWindows(true);
    webView = new WebView(this);
    root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
    setContentView(root);
    WebSettings s = webView.getSettings();
    s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
    s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setSupportZoom(true);
    s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
    picker = new AndroidPicker(this);
    webView.addJavascriptInterface(picker, "AndroidPicker");
    webView.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params){
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(i, 0x1bbd); picker.fileCallback = cb; return true;
      }
    });
    webView.loadUrl("file:///android_asset/index.html");
  }

  @Override protected void onActivityResult(int request, int result, Intent data) {
    super.onActivityResult(request, result, data);
    if (request == 0x1bbd) {
      if (picker.fileCallback != null) {
        Uri[] out = null;
        if (result == RESULT_OK && data != null) {
          ClipData cd = data.getClipData();
          if (cd != null) { out = new Uri[cd.getItemCount()]; for(int i=0;i<out.length;i++) out[i]=cd.getItemAt(i).getUri(); }
          else if (data.getData()!=null) out = new Uri[]{data.getData()};
        }
        picker.fileCallback.onReceiveValue(out); picker.fileCallback=null;
      }
      return;
    }
    if (request == REQUEST_TREE && result == RESULT_OK && data != null && data.getData() != null) {
      Uri tree=data.getData(); try { getContentResolver().takePersistableUriPermission(tree, data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION)); } catch(Exception ignored){}
      new Thread(() -> { try { picker.importTree(tree); runOnUiThread(() -> webView.evaluateJavascript("window.onAndroidLibraryChanged&&window.onAndroidLibraryChanged()", null)); } catch(Exception e) { final String msg=e.getMessage()==null?"Klasör okunamadı":e.getMessage(); runOnUiThread(() -> webView.evaluateJavascript("window.onNativeFiles&&window.onNativeFiles(null,"+JSONObject.quote("Klasör okunamadı: "+msg)+")",null)); } }).start();
    } else if (request == REQUEST_TREE) {
      webView.evaluateJavascript("window.onNativeFiles&&window.onNativeFiles(null,'Klasör seçimi iptal edildi.')", null);
    }
  }

  public class AndroidPicker {
    private final MainActivity a; private ValueCallback<Uri[]> fileCallback;
    private final String PREF="native_folders";
    AndroidPicker(MainActivity x){a=x;}
    @JavascriptInterface public void openFolder(){
      Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION|Intent.FLAG_GRANT_PREFIX_URI_PERMISSION); a.startActivityForResult(i,REQUEST_TREE);
    }
    @JavascriptInterface public String getSavedFolders(){return a.getPreferences(0).getString(PREF,"[]");}
    @JavascriptInterface public String getFileData(String folder,String name){
      try { File f=new File(new File(a.getFilesDir(),"native"),safe(folder)+File.separator+safePath(name)); if(!f.exists())return ""; byte[] b=read(f); String mime=guess(name); return "data:"+mime+";base64,"+Base64.encodeToString(b,Base64.NO_WRAP); } catch(Exception e){return "";}
    }
    @JavascriptInterface public boolean deleteFile(String folder,String name){try{return new File(new File(a.getFilesDir(),"native"),safe(folder)+File.separator+safePath(name)).delete();}catch(Exception e){return false;}}
    private String safe(String s){return String.valueOf(s==null?"":s).replaceAll("[^a-zA-Z0-9._-]","_");}
    private String safePath(String s){String[] p=String.valueOf(s==null?"":s).split("/");StringBuilder b=new StringBuilder();for(String x:p){if(x.length()==0||x.equals("." )||x.equals(".."))continue;if(b.length()>0)b.append(File.separator);b.append(safe(x));}return b.toString();}
    private String guess(String n){String x=n.toLowerCase(Locale.ROOT);if(x.endsWith(".pdf"))return "application/pdf";if(x.endsWith(".png"))return "image/png";if(x.endsWith(".tif")||x.endsWith(".tiff"))return "image/tiff";return "image/jpeg";}
    private byte[] read(File f)throws Exception{ByteArrayOutputStream o=new ByteArrayOutputStream();InputStream in=new FileInputStream(f);byte[] b=new byte[65536];int n;while((n=in.read(b))>0)o.write(b,0,n);in.close();return o.toByteArray();}
    private String displayName(Uri u){Cursor c=a.getContentResolver().query(u,new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME},null,null,null);try{if(c!=null&&c.moveToFirst())return c.getString(0);}finally{if(c!=null)c.close();}return "Klasör";}
    private String docId(Uri u){return DocumentsContract.getTreeDocumentId(u);}
    private boolean supported(String n){String x=n.toLowerCase(Locale.ROOT);return x.endsWith(".pdf")||x.endsWith(".jpg")||x.endsWith(".jpeg")||x.endsWith(".png")||x.endsWith(".tif")||x.endsWith(".tiff");}
    void importTree(Uri tree)throws Exception{
      String folder=displayName(tree), rootName=safe(folder);File root=new File(new File(a.getFilesDir(),"native"),rootName);deleteTree(root);root.mkdirs();JSONArray files=new JSONArray();walk(tree,docId(tree),"",root,files);
      JSONObject rec=new JSONObject();rec.put("name",folder);rec.put("files",files);JSONArray all=new JSONArray(a.getPreferences(0).getString(PREF,"[]"));for(int i=all.length()-1;i>=0;i--)if(folder.equals(all.getJSONObject(i).optString("name")))all.remove(i);all.put(rec);a.getPreferences(0).edit().putString(PREF,all.toString()).apply();
    }
    private void walk(Uri tree,String parent,String rel,File out,JSONArray files)throws Exception{
      Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,parent);Cursor c=a.getContentResolver().query(children,new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE},null,null,null);if(c==null)return;try{while(c.moveToNext()){String id=c.getString(0),name=c.getString(1),mime=c.getString(2),r=rel.length()==0?name:rel+"/"+name;Uri doc=DocumentsContract.buildDocumentUriUsingTree(tree,id);if(DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)){File d=new File(out,safePath(rel.length()==0?name:rel+"/"+name));d.mkdirs();walk(tree,id,r,out,files);}else if(supported(name)){File f=new File(out,safePath(r));File par=f.getParentFile();if(par!=null)par.mkdirs();InputStream in=a.getContentResolver().openInputStream(doc);OutputStream o=new FileOutputStream(f);byte[] b=new byte[65536];int n;while((n=in.read(b))>0)o.write(b,0,n);in.close();o.close();files.put(r);}}}finally{c.close();}}
    private void deleteTree(File f){if(!f.exists())return;if(f.isDirectory()){File[] xs=f.listFiles();if(xs!=null)for(File x:xs)deleteTree(x);}f.delete();}
  }
}
